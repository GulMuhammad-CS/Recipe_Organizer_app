<?php
 include 'db_connect.php';

 //include the Sidebar Menu and Header
 include 'sideBarMenu.php';

 $conn = mysqli_connect($servername, $username, $password, $dbname);

    if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
    }
    else {
        echo "Database Connected successfully";
        //echo $_SESSION['db_connection'];
        //echo "<br> " .mysqli_get_host_info($_SESSION['db_connection']);
    }

    $sql = "SELECT * FROM users"; //Query
    $result = mysqli_query($conn, $sql);

    echo "<br> Total Rows: " . mysqli_num_rows($result);
    echo "<table border='1'>";
    echo "<thead>";
    echo "   <tr>";
    echo "            <th>UserID</th>";
     echo "           <th>Username</th>";
     echo "           <th>Email</th>";
     echo "           <th>Password</th>";
    if (mysqli_num_rows($result) > 0) {
        
        while($row = mysqli_fetch_assoc($result)){

            echo "<tr style='border:1px green solid'>";
            echo "<td>".$row["UserID"]  ."</td>";
            echo    "<td>".$row['Username']. "</td>";
            echo   "<td>".$row['Email']. "</td>";
            echo   "<td>".$row['Password']. "</td>";
        }

    }

?>


<?php

//include the FOOTER Content and END of FILE DATA
include 'footer.php';

?>