<?php
    include 'db_connect.php'; // Includes the connection and starts/resumes the session
    //session_start(); // Start the session at the beginning of your script
    

    //include the Sidebar Menu and Header
    include 'sideBarMenu.php';
?>


                <!-- Begin Page Content -->
                <div class="container-fluid">
                   

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Analytical Queries</h1>
                    <p class="mb-4">
                        </p>
                    
                        <?php
                        //***************************** */
                        // Example Query 1
                        $sql1 = "SELECT users.UserID, users.Username, users.Email
                                FROM users     
                                JOIN user_preference ON users.UserID = user_preference.UserID
                                JOIN dietary_preferences ON user_preference.PreferenceID = dietary_preferences.PreferenceID
                                WHERE dietary_preferences.Preference = 'Halal';";
                        $queryTitle1 = "Query-1";
                        $queryDescription1 = "Retrieve users that can only eat halal food";
                        //CALL FUNCTION to generate table
                        generate_table($conn, $sql1, $queryTitle1, $queryDescription1);

                        //***************************** */
                        // Example Query 2
                        $sql2 = "SELECT recipe.RecipeName AS RecipeTitle, category.Category AS CategoryName 
                                FROM recipe
                                JOIN recipe_category ON recipe.RecipeID = recipe_category.RecipeID 
                                JOIN category ON category.CategoryID = recipe_category.CategoryID 
                                WHERE category.Category = 'Tacos';";
                        $queryTitle2 = "Query-2";
                        $queryDescription2 = "Retrieve recipes that are categorised as tacos";

                        //CALL FUNCTION to generate table
                        generate_table($conn, $sql2, $queryTitle2, $queryDescription2);

                        //***************************** */
                        // Example Query 3
                        $sql2 = "SELECT DISTINCT u.UserID, u.Username, u.Email, up.PreferenceID, dp.Preference
                                FROM users u 
                                JOIN user_preference up  ON u.UserID = up.UserID 
                                JOIN dietary_preferences dp  ON dp.PreferenceID = up.PreferenceID
                                GROUP BY u.UserID
                                HAVING  COUNT(dp.Preference) = 1";
                        $queryTitle2 = "Query-3";
                        $queryDescription2 = "Retrieve all users that specified only 1 dietary preferences";

                        //CALL FUNCTION to generate table
                        generate_table($conn, $sql2, $queryTitle2, $queryDescription2);

                        //***************************** */
                        // Example Query 4
                        $sql2 = "SELECT recipe.RecipeName, COUNT(recipe.RecipeID) AS FavoriteCount 
                        FROM recipe 
                        JOIN user_favourites ON recipe.RecipeID = user_favourites.RecipeID 
                        GROUP BY recipe.RecipeID 
                        ORDER BY FavoriteCount 
                        DESC LIMIT 5;";
                        $queryTitle2 = "Query-4";
                        $queryDescription2 = "Retrieve the top 5 most favourited recipes";

                        //CALL FUNCTION to generate table
                        generate_table($conn, $sql2, $queryTitle2, $queryDescription2);

                        //***************************** */
                        // Example Query 5
                        $sql2 = "SELECT users.UserID, users.Username, recipe.RecipeName, dietary_preferences.Preference 
                        FROM users 
                        JOIN user_favourites ON users.UserID=user_favourites.UserID 
                        JOIN recipe ON user_favourites.RecipeID=recipe.RecipeID 
                        JOIN recipe_preference ON recipe_preference.RecipeID=recipe.RecipeID 
                        JOIN dietary_preferences ON dietary_preferences.PreferenceID=recipe_preference.PreferenceID 
                        LEFT JOIN user_preference ON users.UserID=user_preference.UserID AND dietary_preferences.PreferenceID = user_preference.PreferenceID 
                        WHERE user_preference.PreferenceID IS NULL;";
                        $queryTitle2 = "Query-5";
                        $queryDescription2 = "Retrieve users that have a favourite that does not match their dietary preferences";

                        //CALL FUNCTION to generate table
                        generate_table($conn, $sql2, $queryTitle2, $queryDescription2);

                        //***************************** */
                        // Example Query 
                        $sql2 = "SELECT recipe.RecipeID, recipe.RecipeName, dietary_preferences.Preference FROM recipe JOIN recipe_preference ON recipe.RecipeID=recipe_preference.RecipeID JOIN dietary_preferences ON dietary_preferences.PreferenceID=recipe_preference.PreferenceID where dietary_preferences.Preference='Low-Calorie' OR dietary_preferences.Preference='High-Protein';";
                        $queryTitle2 = "Query-6";
                        $queryDescription2 = "Retrieve recipe that are low in calorie and high in protein";

                        //CALL FUNCTION to generate table
                        generate_table($conn, $sql2, $queryTitle2, $queryDescription2);

                        //***************************** */
                        // Example Query 
                        $sql2 = "SELECT* FROM recipe WHERE NoOfServings>=2";
                        $queryTitle2 = "Query-7";
                        $queryDescription2 = "Retrieve recipes that can serve more than 2 people";

                        //CALL FUNCTION to generate table
                        generate_table($conn, $sql2, $queryTitle2, $queryDescription2);


                        //***************************** */
                        // Example Query 
                        $sql2 = "SELECT recipe.RecipeID, recipe.RecipeName, dietary_preferences.Preference, category.Category FROM recipe JOIN recipe_preference ON recipe.RecipeID = recipe_preference.RecipeID JOIN dietary_preferences ON recipe_preference.PreferenceID = dietary_preferences.PreferenceID JOIN recipe_category ON recipe.RecipeID = recipe_category.RecipeID JOIN category ON recipe_category.CategoryID = category.CategoryID WHERE category.Category = 'Grilled' AND dietary_preferences.Preference = 'Pescatarian';";
                        $queryTitle2 = "Query-8";
                        $queryDescription2 = "Retrieve recipes that are under the category grilled and pescatarian as preference";

                        //CALL FUNCTION to generate table
                        generate_table($conn, $sql2, $queryTitle2, $queryDescription2);


                        //***************************** */
                        // Example Query 
                        $sql2 = "SELECT users.UserID, users.Username, recipe.RecipeName, dietary_preferences.Preference FROM users JOIN user_favourites ON users.UserID=user_favourites.UserID JOIN recipe ON user_favourites.RecipeID=recipe.RecipeID JOIN recipe_preference ON recipe_preference.RecipeID=recipe.RecipeID JOIN dietary_preferences ON dietary_preferences.PreferenceID=recipe_preference.PreferenceID LEFT JOIN user_preference ON users.UserID=user_preference.UserID AND dietary_preferences.PreferenceID = user_preference.PreferenceID WHERE user_preference.PreferenceID IS NOT NULL;";
                        $queryTitle2 = "Query-9";
                        $queryDescription2 = "Retrieve recipes that aren't favourited by users but it matches their preferences";

                        //CALL FUNCTION to generate table
                        generate_table($conn, $sql2, $queryTitle2, $queryDescription2);


                        //***************************** */
                        // Example Query 
                        $sql2 = "select count(*) as NumberOfUsers from users join user_preference on user_preference.UserID=users.UserID join dietary_preferences on dietary_preferences.PreferenceID=user_preference.PreferenceID where dietary_preferences.Preference='Vegetarian';";
                        $queryTitle2 = "Query-10";
                        $queryDescription2 = "Retrieve number of users that prefer vegetarian recipes";

                        //CALL FUNCTION to generate table
                        generate_table($conn, $sql2, $queryTitle2, $queryDescription2);


                        //***************************** */
                        // Example Query 
                        $sql2 = "SELECT u.UserID,u.Username, COUNT(p.PreferenceID) AS more_than_1_preference
                                FROM users u
                                Join user_preference p ON u.UserID = p.UserID
                                GROUP BY u.UserID, u.Username
                                HAVING more_than_1_preference > 1
                                ORDER BY u.UserID ASC
                                ";
                        $queryTitle2 = "Query-11";
                        $queryDescription2 = "Retrieve users that have more than 1 dietary preferences";

                        //CALL FUNCTION to generate table
                        generate_table($conn, $sql2, $queryTitle2, $queryDescription2);


                        //***************************** */
                        // Example Query 
                        $sql2 = "SELECT u.UserID,u.Username, COUNT(f.RecipeID) AS NoOfRecipesFavourited
                                FROM users u
                                Join user_favourites f ON u.UserID = f.UserID
                                GROUP BY u.UserID, u.Username
                                ORDER BY NoOfRecipesFavourited DESC
                                LIMIT 1
                                ";
                        $queryTitle2 = "Query-12";
                        $queryDescription2 = "Retrieve the user with most number of recipes favourited";

                        //CALL FUNCTION to generate table
                        generate_table($conn, $sql2, $queryTitle2, $queryDescription2);


                        //***************************** */
                        // Example Query 
                        $sql2 = "SELECT AVG(preference) AS Average_NoOfPreference
                                FROM(
                                    SELECT u.UserID, COUNT(up.PreferenceID) as preference
                                    FROM users u 
                                    INNER JOIN user_preference up ON u.UserID = up.UserID
                                    GROUP BY u.UserID
                                    ) AS userPreference";
                        $queryTitle2 = "Query-13";
                        $queryDescription2 = "Retrieve the average number of dietary preference only for users that specified their dietary preference ";

                        //CALL FUNCTION to generate table
                        generate_table($conn, $sql2, $queryTitle2, $queryDescription2);


                        //***************************** */
                        // Example Query 
                        $sql2 = "SELECT r.RecipeID,r.RecipeName, r.Description, COUNT(rp.PreferenceID) AS NoOfPreference
                                FROM recipe r 
                                INNER JOIN recipe_preference rp ON rp.RecipeID = r.RecipeID
                                GROUP BY r.RecipeID,r.RecipeName, r.Description
                                HAVING COUNT(rp.PreferenceID) > 1
                                ORDER BY NoOfPreference ASC";
                        $queryTitle2 = "Query-14";
                        $queryDescription2 = "Retrieve recipes that belong to more than 1 preference";

                        //CALL FUNCTION to generate table
                        generate_table($conn, $sql2, $queryTitle2, $queryDescription2);


                        //***************************** */
                        // Example Query 
                        $sql2 = "SELECT u.Username, COUNT(*) AS NumOfFavourites
                                FROM users u
                                JOIN user_favourites uf ON u.UserID = uf.UserID
                                WHERE uf.PostDate >= DATE_SUB(NOW(), INTERVAL 1 WEEK)
                                GROUP BY u.UserID
                                ORDER BY NumOfFavourites DESC;";
                        $queryTitle2 = "Query-15";
                        $queryDescription2 = "Retrieve users that have favourited recipes in the past week";

                        //CALL FUNCTION to generate table
                        generate_table($conn, $sql2, $queryTitle2, $queryDescription2);


                        //***************************** */
                        // Example Query 
                        $sql2 = "SELECT u.UserID, u.Username, COUNT(*) AS NumOfFavourites
                                FROM users u
                                INNER JOIN user_favourites uf ON u.UserID = uf.UserID
                                WHERE uf.PostDate >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
                                GROUP BY u.UserID
                                ORDER BY NumOfFavourites DESC
                                LIMIT 2";
                        $queryTitle2 = "Query-16";
                        $queryDescription2 = "Retrieve the top 2 users with most favourited recipes over the past 6 months";

                        //CALL FUNCTION to generate table
                        generate_table($conn, $sql2, $queryTitle2, $queryDescription2);


                        //***************************** */
                        // Example Query 
                        $sql2 = "SELECT r.RecipeID,r.RecipeName, COUNT(uf.RecipeID) AS NoOfTimesFavourited
                                FROM user_favourites uf
                                INNER JOIN recipe r ON r.RecipeID = uf.RecipeID
                                WHERE uf.PostDate >= DATE_SUB(NOW(), INTERVAL 2 MONTH)
                                GROUP BY r.RecipeID,r.RecipeName
                                ORDER BY NoOfTimesFavourited ASC
                                LIMIT 3";
                        $queryTitle2 = "Query-17";
                        $queryDescription2 = "Retrieve the 3 least favourited recipes over the past 2 months";

                        //CALL FUNCTION to generate table
                        generate_table($conn, $sql2, $queryTitle2, $queryDescription2);


                        //***************************** */
                        // Example Query 
                        $sql2 = "SELECT DISTINCT u.UserID, u.Username, u.Email
                                FROM users u 
                                INNER JOIN user_preference up ON u.UserID = up.UserID
                                LEFT JOIN user_favourites uf ON u.UserID = uf.UserID
                                WHERE uf.RecipeID IS NULL
                                ";
                        $queryTitle2 = "Query-18";
                        $queryDescription2 = "Retrieve users that have specified their dietary preferences but have not favourited any recipes";

                        //CALL FUNCTION to generate table
                        generate_table($conn, $sql2, $queryTitle2, $queryDescription2);


                        //***************************** */
                        // Example Query 
                        $sql2 = "SELECT AVG(r.PreparationTimeInMinutes) AS AveragePreparationTime_InMinutes
                                FROM recipe r
                                INNER JOIN recipe_category rc ON r.RecipeID = rc.RecipeID
                                INNER JOIN category c ON rc.CategoryID = c.CategoryID
                                WHERE c.Category != 'Beverage'";
                        $queryTitle2 = "Query-19";
                        $queryDescription2 = "Retrieve the average preparation time for all recipes except recipes categorised as beverage";

                        //CALL FUNCTION to generate table
                        generate_table($conn, $sql2, $queryTitle2, $queryDescription2);


                        //***************************** */
                        // Example Query 
                        $sql2 = "SELECT COUNT(DISTINCT up.UserID) AS NoOfUsers
                                FROM user_preference up
                                INNER JOIN user_favourites uf ON up.UserID = uf.UserID
                                ";
                        $queryTitle2 = "Query-20";
                        $queryDescription2 = "Retrieve the number of users that have specified their dietary preferences and have favourited recipes";

                        //CALL FUNCTION to generate table
                        generate_table($conn, $sql2, $queryTitle2, $queryDescription2);

                        //***************************** */
                        // Example Query 
                        $sql2 = "SELECT DISTINCT u.UserID, u.Username, u.Email
                                FROM users u
                                LEFT JOIN user_preference up ON up.UserID = u.UserID
                                WHERE up.PreferenceID IS NULL
                                ";
                        $queryTitle2 = "Query-21";
                        $queryDescription2 = "Retrieve users that do not have any dietary preferences";

                        //CALL FUNCTION to generate table
                        generate_table($conn, $sql2, $queryTitle2, $queryDescription2);



                        // Add more queries as needed...
                        ?>

                </div> 
                <!-- /.container-fluid -->

<?php

//include the FOOTER Content and END of FILE DATA
include 'footer.php';

?>

<?php
/// *** NO NEED TO CHANGE ANYTHING BELOW THIS LINE *** ///

// Function to execute the query and generate the table
function generate_table($conn, $sql, $queryTitle, $queryDescription) {
    echo '<div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">' . $queryTitle . '</h6>
                <p class="mb-4">' . $queryDescription . '</p>
            </div>
            <div class="card-body">
                <div class="table-responsive">';
    
    // Execute the Query
    $result = mysqli_query($conn, $sql);

    // Display the number of rows
    echo "<br> Total Rows: " . mysqli_num_rows($result);

    if (mysqli_num_rows($result) > 0) {
        // Display table header with column names dynamically
        echo "<table border='1' class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
        echo "<tr>";
        
        $firstRow = mysqli_fetch_assoc($result);
        // Loop through and print all column names
        foreach ($firstRow as $columnName => $value) {
            echo "<th>" . htmlspecialchars($columnName) . "</th>";
        }
        echo "</tr>";

        // Reset the pointer to the first row
        mysqli_data_seek($result, 0);

        // Output data of each row dynamically
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            foreach ($row as $columnValue) {
                echo "<td>" . htmlspecialchars($columnValue) . "</td>";
            }
            echo "</tr>";
        }

        echo "</table>";
    } else {
        echo "0 results";
    }

    echo '    </div>
            </div>
        </div>';
}
?>
